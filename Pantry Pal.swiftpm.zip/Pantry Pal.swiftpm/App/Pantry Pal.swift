/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

@main
struct PantryPal: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
