/*
See the License.txt file for this sample’s licensing information.
*/

import Foundation
import SwiftUI

struct Info {
    let image: String
    let name: String
    let rice: String
    let bread: String
    let tomato:String
    let cheese: String
    let eggs: String
    let carrot: String
    let lettuce: String
    let jam: String
    let EggFriedRice: String
    let VegetableSalad: String
}

let information = Info(
    image: "logo",
    name: "Pantry Pal",
    rice: "Rice",
    bread: "Bread",
    tomato: "Tomato",
    cheese: "Cheese",
    eggs: "Eggs",
    carrot: "Carrot",
    lettuce: "Lettuce",
    jam: "Jam",
    EggFriedRice: "Egg Fried Rice",
    VegetableSalad: "Vegetable Salad"
)
    
    
